package com.cg.hbm.exceptions;


@SuppressWarnings("serial")
public class HotelNotFoundException extends Exception {
	
	public HotelNotFoundException(String message) {
		super(message);
	}
	}


